import sys
import re


def ler_dados(arquivo):
    # Abre o arquivo para leitura
    file = open(arquivo, "r")

    # Lê as linhas do arquivo
    texto = file.readlines()
    text = ""

    # Concatena as linhas em uma única string
    for t in texto:
        text = text + str(t)

    # Usa expressões regulares para extrair informações do arquivo
    match = re.findall(r'({.*?})|(q[0-9]+)', "".join(text.split()))

    # Verifica se houve correspondências com as expressões regulares
    if match:
        # Armazena as palavras extraídas
        extracted_words = [match for match in match]

    # Extrai os estados do primeiro conjunto
    estados = extracted_words[0][0].split(",")
    estados[0] = estados[0][1:]  # Remove o '{' do primeiro estado
    estados[-1] = estados[-1][:-1]  # Remove o '}' do último estado

    # Extrai o alfabeto de entrada do segundo conjunto
    alfabeto_entrada = extracted_words[1][0].split(",")
    # Remove o '{' do primeiro símbolo
    alfabeto_entrada[0] = alfabeto_entrada[0][1:]
    # Remove o '}' do último símbolo
    alfabeto_entrada[-1] = alfabeto_entrada[-1][:-1]

    # Extrai o alfabeto da fita do terceiro conjunto
    alfabeto_fita = extracted_words[2][0].split(",")
    alfabeto_fita[0] = alfabeto_fita[0][1:]  # Remove o '{' do primeiro símbolo
    # Remove o '}' do último símbolo
    alfabeto_fita[-1] = alfabeto_fita[-1][:-1]

    # Extrai as transições do quarto conjunto
    transicoes = extracted_words[3][0]
    transicoes = transicoes.split("),(")

    # Limpa e formata as transições
    transicoes = [elem.replace("(", "").replace(")", "").replace(
        "{", "").replace("}", "").replace("->", ",") for elem in transicoes]
    transicoes = [elem.split(',') for elem in transicoes]

    # Extrai o estado inicial do quinto conjunto
    estadoInicial = extracted_words[4][1]

    # Extrai os estados finais do sexto conjunto
    estadoFinal = extracted_words[5][0]
    estadoFinal = estadoFinal.split(",")
    # Remove o '{' do primeiro estado final
    estadoFinal[0] = estadoFinal[0][1:]
    # Remove o '}' do último estado final
    estadoFinal[-1] = estadoFinal[-1][:-1]

    # Retorna todas as informações extraídas
    return estados, alfabeto_entrada, alfabeto_fita, transicoes, estadoInicial, estadoFinal


def processTuringMachine(chain, mt, output):
    # Abre o arquivo de saída para escrita
    with open(output, 'w') as arquivoSaida:
        # Inicializa o estado atual com o estado inicial da MT
        estadoAtual = mt['estadoInicial']
        # Inicializa a posição da cabeça de leitura/escrita na fita
        posicaoTape = 0
        # Remove espaços em branco dos estados finais
        mt['estadoFinal'] = [element.strip() for element in mt['estadoFinal']]

        # Inicializa a fita com a cadeia de entrada e um símbolo de branco 'B'
        tape = list(chain) + ['B']
        # Escreve a configuração inicial da fita no arquivo de saída
        arquivoSaida.write(f"{fita_to_str(tape, posicaoTape, estadoAtual)}\n")

        # Loop principal que simula a execução da Máquina de Turing
        while True:
            # Inicializa a variável para verificar se há movimentos válidos
            movimento_valido = False

            # Itera sobre as transições definidas na MT
            for transicao in mt['transicoes']:
                # Verifica se a transição é aplicável ao estado atual e símbolo na fita
                if transicao[0].strip() == estadoAtual.strip() and transicao[1].strip() == tape[posicaoTape]:
                    # Atualiza o estado atual
                    estadoAtual = transicao[2]
                    # Atualiza o símbolo na fita
                    tape[posicaoTape] = transicao[3].strip()

                    # Move a cabeça de leitura/escrita para a esquerda (E) ou direita (D)
                    if transicao[4] == 'E':
                        posicaoTape = posicaoTape - 1
                    elif transicao[4] == 'D':
                        posicaoTape = posicaoTape + 1

                    # Indica que um movimento válido foi realizado
                    movimento_valido = True
                    break

            # Converte a fita para string e escreve no arquivo de saída
            fita_atual = ''.join(tape)
            arquivoSaida.write(
                f"{fita_to_str(tape, posicaoTape, estadoAtual)}\n")

            # Se a fita terminar com 'B' e não houver mais de 2 'B's, acrescenta mais um 'B'
            if fita_atual.endswith('B') and fita_atual.count('B') <= 2:
                tape += ['B'] * 1

            # Se o estado atual está nos estados finais, aceita a cadeia
            if estadoAtual.strip() in mt['estadoFinal']:
                arquivoSaida.write("aceita\n")
                break
            # Se não houver movimentos válidos, interrompe a execução
            elif not movimento_valido:
                break


def fita_to_str(tape, posicaoTape, estadoAtual):
    # Obtém os três últimos símbolos na fita
    ultimos_tres = tape[-3:]

    # Calcula a posição dos espaços em branco na representação visual da fita
    if ultimos_tres.count('B') >= 2:
        posicao_espacos = len(tape) // 2 - posicaoTape - 1
    else:
        posicao_espacos = len(tape) // 2 - posicaoTape

    # Formata o estado atual com chaves se não for um símbolo de branco> utilizado para evitar erros.
    estado_formatado = '{{{}}}'.format(
        estadoAtual) if estadoAtual != 'B' else estadoAtual

    # Constrói a representação visual da fita como uma string
    fita_str = ''.join(tape[:posicaoTape]) + estado_formatado + \
        tape[posicaoTape] + ''.join(tape[posicaoTape + 1:])

    # Remove o último símbolo de branco se necessário
    if len(tape) > 2 and tape[-1] == 'B' and ultimos_tres.count('B') >= 2:
        fita_str = fita_str[:-1]

    return fita_str


def main(configTM, chain, output):
    estados, alfabeto_entrada, alfabeto_fita, transicoes, estadoInicial, estadoFinal = ler_dados(
        configTM)

    mt = {}
    mt['estados'] = estados
    mt['alfabetoEntrada'] = alfabeto_entrada
    mt['alfabetoFita'] = alfabeto_fita
    mt['transicoes'] = transicoes
    mt['estadoInicial'] = estadoInicial
    mt['estadoFinal'] = estadoFinal

    chain = 'B' + chain

    processTuringMachine(chain, mt, output)


if __name__ == "__main__":
    if len(sys.argv) == 3:
        main(sys.argv[1], '', sys.argv[2])
    elif len(sys.argv) == 4:
        main(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print(
            "Uso: python3 main.py <ArquivoConfigMT> [<Cadeia>] [<ArquivoSaida>]")
        sys.exit(1)
