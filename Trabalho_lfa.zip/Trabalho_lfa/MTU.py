import sys
import re

# A dictionary to hold the new encoding scheme based on the image
encoding_scheme = {
    '0': '1',
    '1': '11',
    'B': '111',
    'D': '11',
    'E': '1'
  
}

# Function to encode a symbol based on the unary encoding scheme
def encode_symbol(symbol):
    # Check if it's a state symbol like q0, q1, etc.
    if symbol.startswith('q'):
        # Extract the state number from the symbol and use it to create the encoding
        state_number = int(symbol[1:])
        return '1' * (state_number + 1)
    else:
        # For other symbols, use the encoding scheme directly
        return encoding_scheme.get(symbol, symbol)

# Function to print the Turing Machine based on the components
def print_turing_machine(mt):
    print("Turing Machine Configuration:")
    print("States:", mt['estados'])
    print("Input Alphabet:", mt['alfabetoEntrada'])
    print("Tape Alphabet:", mt['alfabetoFita'])
    print("Transitions:")
    for transition in mt['transicoes']:
        print(" ", transition)
    print("Initial State:", mt['estadoInicial'])
    print("Final States:", mt['estadoFinal'])

def ler_dados(arquivo):
    # Abre o arquivo para leitura
    file = open(arquivo, "r")

    # Lê as linhas do arquivo
    texto = file.readlines()
    text = ""

    # Concatena as linhas em uma única string
    for t in texto:
        text = text + str(t)

    # Usa expressões regulares para extrair informações do arquivo
    match = re.findall(r'({.*?})|(q[0-9]+)', "".join(text.split()))

    # Verifica se houve correspondências com as expressões regulares
    if match:
        # Armazena as palavras extraídas
        extracted_words = [match for match in match]

    # Extrai os estados do primeiro conjunto
    estados = extracted_words[0][0].split(",")
    estados[0] = estados[0][1:]  # Remove o '{' do primeiro estado
    estados[-1] = estados[-1][:-1]  # Remove o '}' do último estado

    # Extrai o alfabeto de entrada do segundo conjunto
    alfabeto_entrada = extracted_words[1][0].split(",")
    # Remove o '{' do primeiro símbolo
    alfabeto_entrada[0] = alfabeto_entrada[0][1:]
    # Remove o '}' do último símbolo
    alfabeto_entrada[-1] = alfabeto_entrada[-1][:-1]

    # Extrai o alfabeto da fita do terceiro conjunto
    alfabeto_fita = extracted_words[2][0].split(",")
    alfabeto_fita[0] = alfabeto_fita[0][1:]  # Remove o '{' do primeiro símbolo
    # Remove o '}' do último símbolo
    alfabeto_fita[-1] = alfabeto_fita[-1][:-1]

    # Extrai as transições do quarto conjunto
    transicoes = extracted_words[3][0]
    transicoes = transicoes.split("),(")

    # Limpa e formata as transições
    transicoes = [elem.replace("(", "").replace(")", "").replace(
        "{", "").replace("}", "").replace("->", ",") for elem in transicoes]
    transicoes = [elem.split(',') for elem in transicoes]

    # Extrai o estado inicial do quinto conjunto
    estadoInicial = extracted_words[4][1]

    # Extrai os estados finais do sexto conjunto
    estadoFinal = extracted_words[5][0]
    estadoFinal = estadoFinal.split(",")
    # Remove o '{' do primeiro estado final
    estadoFinal[0] = estadoFinal[0][1:]
    # Remove o '}' do último estado final
    estadoFinal[-1] = estadoFinal[-1][:-1]

    # Retorna todas as informações extraídas
    return estados, alfabeto_entrada, alfabeto_fita, transicoes, estadoInicial, estadoFinal


def main(configTM, chain, output):
    estados, alfabeto_entrada, alfabeto_fita, transicoes, estadoInicial, estadoFinal = ler_dados(
    configTM)

    # Use the encode_symbol function to encode the TM components
    encoded_states = [encode_symbol(state) for state in estados]
    encoded_input_alphabet = [encode_symbol(symbol) for symbol in alfabeto_entrada]
    encoded_tape_alphabet = [encode_symbol(symbol) for symbol in alfabeto_fita]
    encoded_transitions = [[encode_symbol(part) for part in transition] for transition in transicoes]
    encoded_initial_state = encode_symbol(estadoInicial)
    encoded_final_states = [encode_symbol(state) for state in estadoFinal]

    # Update the Turing Machine dictionary with the encoded components
    mt = {}
    mt['estados'] = encoded_states
    mt['alfabetoEntrada'] = encoded_input_alphabet
    mt['alfabetoFita'] = encoded_tape_alphabet
    mt['transicoes'] = encoded_transitions
    mt['estadoInicial'] = encoded_initial_state
    mt['estadoFinal'] = encoded_final_states

    # Print the encoded Turing Machine
    print_turing_machine(mt)

if __name__ == "__main__":
    if len(sys.argv) == 3:
        main(sys.argv[1], '', sys.argv[2])
    elif len(sys.argv) == 4:
        main(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print(
            "Uso: python3 main.py <ArquivoConfigMT> [<Cadeia>] [<ArquivoSaida>]")
        sys.exit(1)