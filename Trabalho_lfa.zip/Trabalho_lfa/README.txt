Maquina de Turing

Descrição:

O programa le um arquivo .txt que possui a maquina de Turing. Ao realizar todas as transicoes, escreve em outro arquivo (de saida) cada iteracao, e se aceita a palavra de entrada.

Instalacao:

E necessario ter o interpretador da linguagem python previamente instalado (pip install python), e os arquivos essencias ja baixados. 

Uso:

Para utilizar, digite: python3 main.py <arg1> palavra <arg2>
Utilizando o arquivo de teste fornecido, devemos utilizar, por exemplo: python3 main.py desc_mt1.txt aaabbb saida.txt
(verifique estar no mesmo diretorio)

Contribuição: 

Bernardo Bertante Martins
Esther Silva de Magalhaes 
Felipe Mateus Maximiniano e Silva Ribeiro 
Ramon Damasceno Nascimento